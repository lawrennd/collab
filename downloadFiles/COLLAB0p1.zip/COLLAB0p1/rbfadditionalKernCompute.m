function [k, sk, n2] = rbfadditionalKernCompute(kern, x, x2)

% RBFADDITIONALKERNCOMPUTE Compute the RBF kernel given the parameters and X.
%
%	Description:
%
%	K = RBFADDITIONALKERNCOMPUTE(KERN, I, I2) computes the kernel
%	parameters for the radial basis function kernel given inputs
%	associated with rows and columns.
%	 Returns:
%	  K - the kernel matrix computed at the given points.
%	 Arguments:
%	  KERN - the kernel structure for which the matrix is computed.
%	  I - the index of the input matrix associated with the rows of the
%	   kernel.
%	  I2 - the index of the input matrix associated with the columns of
%	   the kernel.
%	DESC computes the kernel matrix for the
%	radial basis function kernel given a design matrix of inputs.
%	RETURN k : the kernel matrix computed at the given points.
%	ARG kern : the kernel structure for which the matrix is computed.
%	ARG i : the index of the input data matrix in the form of a design matrix.
%	
%	rbfadditionalKernDiagCompute
%	
%	
%
%	See also
%	RBFADDITIONALKERNPARAMINIT, KERNCOMPUTE, KERNCREATE, 


%	Copyright (c) 2009 Raquel Urtasun
%	Copyright (c) 2004, 2005, 2006 Neil D. Lawrence
% 	rbfadditionalKernCompute.m SVN version 334
% 	last update 2009-05-04T16:56:38.000000Z
  
if nargin < 3
  n2 = dist2(kern.additional(x,:), kern.additional(x,:));
  wi2 = (.5 .* kern.inverseWidth);
  sk = exp(-n2*wi2);
else
  n2 = dist2(kern.additional(x,:), kern.additional(x2,:));
  wi2 = (.5 .* kern.inverseWidth);
  sk = exp(-n2*wi2);
end
k = sk*kern.variance;