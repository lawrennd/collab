function options = collabOptionsTensor(approx);

% COLLABOPTIONSTENSOR Return default options for COLLAB model with a tensor
%
%	Description:
%
%	OPTIONS = COLLABOPTIONSTENSOR returns the default options in a
%	structure for a COLLAB model.
%	 Returns:
%	  OPTIONS - structure containing the default options for the given
%	   approximation type.
%	
%
%	See also
%	COLLABCREATETENSOR


%	Copyright (c) 2008 Raquel Urtasun
% 	collabOptionsTensor.m SVN version 207
% 	last update 2009-05-04T16:56:38.000000Z


  options.kern = {'cmpnd', {'tensor', 'rbf', 'rbf'}, 'bias', 'white'};
  options.numActive = 0;
  options.beta = [];

end
