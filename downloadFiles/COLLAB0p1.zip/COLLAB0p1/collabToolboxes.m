
% COLLABTOOLBOXES Load in the relevant toolboxes for collaborative filtering.
%
%	Description:
%	% 	collabToolboxes.m SVN version 342
% 	last update 2009-05-07T09:07:20.000000Z
importLatest('netlab');
importLatest('ndlutil');
importLatest('mltools');
importLatest('optimi');
importLatest('datasets');
importLatest('kern');
importLatest('ivm');
importLatest('gplvm');
importLatest('noise');