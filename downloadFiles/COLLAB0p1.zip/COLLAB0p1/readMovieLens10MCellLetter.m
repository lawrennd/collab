function [Y, Ytest] = readMovieLens10MCellLetter(partLetter)

% READMOVIELENS10MCELLLETTER Read the 10M Movielens into a cell array.
%
%	Description:
%
%	[Y, YTEST] = READMOVIELENS10MCELLLETTER(PARTLETTER) reads the 10M
%	MovieLens data into a cell array.
%	 Returns:
%	  Y - the data in a cell array.
%	  YTEST - the test data in a cell array. read the 10M movielens in a
%	   cell array. It is too big to do the regular way
%	 Arguments:
%	  PARTLETTER - the part of the 10M MovieLens data to read in.
%	
%
%	See also
%	COLLABLOADDATA


%	Copyright (c) 2009 Raquel Urtasun
% 	readMovieLens10MCellLetter.m SVN version 342
% 	last update 2009-05-06T08:54:40.000000Z

  
  baseDir = datasetsDirectory;
  dirSep = filesep;
  
  % load the ratings
  
  fileName = [baseDir dirSep 'movielens' dirSep '10M' dirSep 'r',num2str(partLetter),'.train'];
  [users, films, ratings, timeStamp] = textread(fileName, '%n::%n::%n::%n');
  
  
  [Y] = loadSparse10M(users,films,ratings);
  
  
  fileName = [baseDir dirSep 'movielens' dirSep '10M' dirSep 'r',num2str(partLetter),'.test'];
  [users_test, films_test, ratings_test, timeStamp] = textread(fileName, '%n::%n::%n::%n');
  
  
  [Ytest] = loadSparse10M(users_test,films_test,ratings_test);
end


