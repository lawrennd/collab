function [Y, lbls, Ytest] = readEachMovieMarlinStrong(partNo)

% READEACHMOVIEMARLINSTRONG Reads the EachMovie strong partitions from Marlin.
%
%	Description:
%
%	[Y, YTEST] = READEACHMOVIEMARLINSTRONG(PARTLETTER) reads the
%	EachMovie Marlin strong partitions.
%	 Returns:
%	  Y - the data.
%	  YTEST - the test data.
%	 Arguments:
%	  PARTLETTER - the part of the 10M MovieLens data to read in.
%	
%
%	See also
%	COLLABLOADDATA, READEACHMOVIEMARLINWEAK


%	Copyright (c) 2009 Raquel Urtasun
% 	readEachMovieMarlinStrong.m SVN version 348
% 	last update 2009-05-14T18:36:31.000000Z

lbls = [];

baseDir = datasetsDirectory;
dirSep = filesep;

% load the ratings
fileName = [baseDir dirSep 'collab' dirSep 'project' dirSep 'em-mmmf' dirSep 'data' dirSep 'marlin.mat'];

disp(['Reading ... ',fileName]);

load(fileName);

Y = weaktrain{partNo}';
Ytest = strongtest{partNo}';
lbls = strongtrain{partNo}';

