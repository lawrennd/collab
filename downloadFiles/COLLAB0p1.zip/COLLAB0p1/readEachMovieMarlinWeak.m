function [Y, Ytest] = readEachMovieMarlinWeak(partNo)

% READEACHMOVIEMARLINWEAK Read in Marlin's weak partitions for EachMovie.
%
%	Description:
%
%	[Y, YTEST] = READEACHMOVIEMARLINWEAK(PARTNO) reads the EachMovie
%	Marlin weak partitions.
%	 Returns:
%	  Y - the data.
%	  YTEST - the test data.
%	 Arguments:
%	  PARTNO - the part of the EachMovie data to read in.
%	
%
%	See also
%	COLLABLOADDATA, READEACHMOVIEMARLINSTRONG


%	Copyright (c) 2009 Raquel Urtasun
% 	readEachMovieMarlinWeak.m SVN version 347
% 	last update 2009-05-14T18:30:17.000000Z
  
  baseDir = datasetsDirectory;
  dirSep = filesep;
  
  % load the ratings
  
  
  fileName = [baseDir dirSep 'collab' dirSep 'project' dirSep 'em-mmmf' dirSep 'data' dirSep 'marlin.mat'];
  
  disp(['Reading ... ',fileName]);
  
  load(fileName);
  
  Y = weaktrain{partNo}';
  Ytest = weaktest{partNo}';
end

