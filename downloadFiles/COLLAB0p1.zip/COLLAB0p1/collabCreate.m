function model = collabCreate(q, d, N, options);

% COLLABCREATE Create a COLLAB model with inducing varibles/pseudo-inputs.
%
%	Description:
%
%	MODEL = COLLABCREATE(Q, D, OPTIONS) creates a collaborative filter
%	structure with a latent space of q.
%	 Returns:
%	  MODEL - model structure containing the GP collaborative filter.
%	 Arguments:
%	  Q - input data dimension.
%	  D - the number of processes (i.e. output data dimension).
%	  OPTIONS - options structure as defined by collabOptions.m.
%	
%
%	See also
%	COLLABOPTIONS, MODELCREATE


%	Copyright (c) 2008 Neil D. Lawrence
% 	collabCreate.m SVN version 339
% 	last update 2009-05-04T16:56:38.000000Z


model.type = 'collab';

model.q = q;
model.d = d;
model.N = N;
model.kern = kernCreate(q, options.kern);
%initParams = collabExtractParam(model);
model.X = randn(N, q)*0.001;
model.change = zeros(size(model.X));
model.changeParam = zeros(1, model.kern.nParams);
model.mu = zeros(N, 1);
model.sd = ones(N, 1);
% This forces kernel computation.
%model = collabExpandParam(model, initParams);
