function options = collabOptions(approx);

% COLLABOPTIONS Return default options for COLLAB model.
%
%	Description:
%
%	OPTIONS = COLLABOPTIONS returns the default options in a structure
%	for a COLLAB model.
%	 Returns:
%	  OPTIONS - structure containing the default options for the given
%	   approximation type.
%	
%
%	See also
%	COLLABCREATE


%	Copyright (c) 2008 Neil D. Lawrence
% 	collabOptions.m SVN version 339
% 	last update 2009-05-04T16:56:38.000000Z

  options.kern = {'rbf', 'bias', 'white'};
  options.numActive = 0;
  options.beta = [];

end
