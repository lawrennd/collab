% COLLAB toolbox
% Version 0.1		14-May-2009
% Copyright (c) 2009, Neil D. Lawrence
% 
, Neil D. Lawrence
% COLLABLOGLIKEGRADIENTS Gradient of the latent points.
% COLLABOPTIONSTENSOR Return default options for COLLAB model with a tensor
% READMOVIELENSMARLINWEAK Read in Marlin's weak partitions for movielens 1M.
% RBFADDITIONALKERNDIAGGRADX Gradient of RBF with side information kernel's
% DEMMOVIELENSMARLINSTRONGLINEARSCRIPT1 Movielens strong generalization linear + RBF kernel.
% READEACHMOVIEMARLINSTRONG Reads the EachMovie strong partitions from Marlin.
% DEMMOVIELENS2 Try collaborative filtering on the large movielens data.
% DEMMOVIELENS4 Try collaborative filtering on the large movielens data.
% DEMEACHMOVIEMARLINWEAKLINEAR Linear covariance on Marlin's weak Eachmovie partitions.
% COLLABLOADDATA Load a collaborative filtering dataset.
% DEMEACHMOVIEMARLINSTRONGLINEARSCRIPT1 EachMovie strong generalization with linear covariance.
% RBFADDITIONALKERNDIAGCOMPUTE Compute diagonal of RBF side information kernel.
% READEACHMOVIEMARLINWEAK Read in Marlin's weak partitions for EachMovie.
% DEMMOVIELENS10MLETTERWEAKSCRIPT1 Try collaborative filtering on the 10M movielens data set.
% RBFADDITIONALKERNGRADIENT Gradient of RBF with side information kernel's parameters.
% DEMNETFLIX5 Try collaborative filtering on the netflix data.
% DEMMOVIELENSMARLINWEAKENSEMSCRIPT1 Ensemble of models on Marlin's weak Movielens partions.
% DEMMOVIELENSORDERED1 Try collaborative filtering on the large movielens data.
% DEMMOVIELENS3 Try collaborative filtering on the large movielens data.
% COLLABLOGLIKELIHOOD Compute the log likelihood of a COLLAB.
% RBFADDITIONALKERNEXTRACTPARAM Extract parameters from the RBF with side
% COLLABOPTIONS Return default options for COLLAB model.
% DEMEACHMOVIEMARLINSTRONGSCRIPT1 EachMovie strong generalization.
% DEMMOVIELENS1 Try collaborative filtering on the large movielens data.
% DEMMOVIELENSMARLINWEAKMLPSCRIPT1 MLP covariance on Marlin's weak Movielens partitions.
% RBFADDITIONALKERNEXPANDPARAM Create kernel structure from RBF kernel's parameters.
% COLLABDISPLAY Displays the provided collaborative filter model.
% COMPUTETESTERRORWEAKCELL Compute the weak test error for data stored in a cell array.
% RBFADDITIONALKERNGRADX Gradient of RBF kernel with respect to input locations.
% COLLABPOSTERIORMEANVARCELL Mean and variances of the posterior at points given by X.
% COLLABOPTIMISEOPTIONS returns default options for collaborative filter optimisation.
% READMOVIELENS10MCELLLETTER Read the 10M Movielens into a cell array.
% DEMMOVIELENSMARLINSTRONGADDITIONALSCRIPT1 Movielens strong generalization with additional infromation.
% DEMMOVIELENS10MWEAKSCRIPT1 Try collaborative filtering on the 10M movielens data set.
% DEMMOVIELENSMARLINSTRONGLINEARRBFSCRIPT1 
% READEACHMOVIEWEAK Read in EachMovie users with over 20 ratings.
% COMPUTETESTERRORWEAK Compute the weak test error.
% DEMMOVIELENSMARLINWEAKSCRIPT1 RBF covariance on Marlin's weak Movielens partitions.
% COLLABCREATE Create a COLLAB model with inducing varibles/pseudo-inputs.
% DEMMOVIELENSMARLINWEAKLINEARRBFSCRIPT1 Collaborative filtering on Marlin's weak partitions using RBF + linear.
% DEMEACHMOVIEMARLINWEAKSCRIPT1 RBF covariance on Marlin's weak Eachmovie partitions.
% DEMNETFLIX1 Try collaborative filtering on the netflix data.
% DEMMOVIELENSMARLINSTRONGSCRIPT1 Movielens strong generalization.
% DEMMOVIELENSSMALL1 Try collaborative filtering on the small movielens data.
% COLLABTOOLBOXES Load in the relevant toolboxes for collaborative filtering.
% DEMNETFLIX2 Try collaborative filtering on the netflix data.
% READMOVIELENSMARLINSTRONG Read in Marlin's strong partitions for movielens 1M.
% DEMEACHMOVIEMARLINWEAKENSEMSCRIPT1 Ensemble of models on Marlin's weak Eachmovie partions.
% COLLABOPTIMISE Optimise the collaborative filter.
% RBFADDITIONALKERNPARAMINIT RBF kernel with side information.
% DEMNETFLIX3 Try collaborative filtering on the netflix data.
% DEMMOVIELENSMARLINWEAKLINEARSCRIPT1 Linear covariance on Marlin's weak Movielens partitions.
% DEMMOVIELENSMARLINWEAKADDITIONALSCRIPT1 Collaborative filtering on Marlin's weak partitions.
% RBFADDITIONALKERNCOMPUTE Compute the RBF kernel given the parameters and X.
% COLLABPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% READMOVIELENSSTRONG Read in the strong partitions for the Movielens.
