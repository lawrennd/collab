function gX = rbfadditionalKernDiagGradX(kern, X)

% RBFADDITIONALKERNDIAGGRADX Gradient of RBF with side information kernel's
%
%	Description:
%	diagonal with respect to X.
%
%	GX = RBFADDITIONALKERNDIAGGRADX(KERN, X) computes the gradient of
%	the diagonal of the radial basis function side information kernel
%	matrix with respect to the elements of the design matrix given in X.
%	 Returns:
%	  GX - the gradients of the diagonal with respect to each element of
%	   X. The returned matrix has the same dimensions as X.
%	 Arguments:
%	  KERN - the kernel structure for which gradients are being
%	   computed.
%	  X - the input data in the form of a design matrix.
%	
%	
%
%	See also
%	RBFADDITIONALKERNPARAMINIT, KERNDIAGGRADX, RBFADDITIONALKERNGRADX


%	Copyright (c) 2004, 2005, 2006 Neil D. Lawrence
%	Copyright (c) 2009 Raquel Urtasun
% 	rbfadditionalKernDiagGradX.m SVN version 334
% 	last update 2009-05-04T16:56:38.000000Z

gX = zeros(size(X));

