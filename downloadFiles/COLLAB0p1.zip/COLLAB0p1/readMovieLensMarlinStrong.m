function [Y, lbls, Ytest] = readMovieLensMarlinStrong(partNo)

% READMOVIELENSMARLINSTRONG Read in Marlin's strong partitions for movielens 1M.
%
%	Description:
%
%	[Y, LBLS, YTEST] = READMOVIELENSMARLINSTRONG(PARTNO) reads the
%	Movielens 1M Marlin strong partitions.
%	 Returns:
%	  Y - the data.
%	  LBLS - the labels associated with the movies.
%	  YTEST - the test data.
%	 Arguments:
%	  PARTNO - the part of the Movielens data to read in.
%	
%
%	See also
%	COLLABLOADDATA, READMOVIELENSMARLINWEAK


%	Copyright (c) 2009 Raquel Urtasun
% 	readMovieLensMarlinStrong.m SVN version 348
% 	last update 2009-05-14T18:34:03.000000Z


lbls = [];

baseDir = datasetsDirectory;
dirSep = filesep;

% load the ratings


fileName = [baseDir dirSep 'collab' dirSep 'project' dirSep '1mml-mmmf' dirSep 'data' dirSep 'marlin.mat'];

disp(['Reading ... ',fileName]);

load(fileName);

Y = weaktrain{partNo}';
lbls = strongtrain{partNo}';
Ytest = strongtest{partNo}';


        
