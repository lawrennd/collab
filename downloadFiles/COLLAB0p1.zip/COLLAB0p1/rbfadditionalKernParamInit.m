function kern = rbfadditionalKernParamInit(kern)

% RBFADDITIONALKERNPARAMINIT RBF kernel with side information.
%
%	Description:
%
%	RBFADDITIONALKERNPARAMINIT
%	k(x_i, x_j) = sigma2 * exp(-gamma/2 *(additional(x_i) - additional(x_j))'*(additional(x_i) - additional(x_j)))
%	
%	The parameters are sigma2, the process variance (kern.variance) and gamma,
%	the inverse width (kern.inverseWidth). The inverse width controls how wide
%	the basis functions are, the larger gamma, the smaller the basis functions
%	are.
%	r
%	DESC computes the RBF kernel with the side information for
%	collaborative filtering.
%	RETURN kern : the kernel structure with the default parameters placed in.
%	ARG kern : the kernel structure which requires initialisation.
%	
%	
%	
%
%	See also
%	RBFKERNPARAMINIT, KERNCREATE, KERNPARAMINIT


%	Copyright (c) 2009 Raquel Urtasun
%	Copyright (c) 2004, 2005, 2006 Neil D. Lawrence
% 	rbfadditionalKernParamInit.m SVN version 334
% 	last update 2009-05-04T16:56:38.000000Z

kern.inverseWidth = 1;
kern.variance = 1;
kern.nParams = 2;

% Constrains parameters positive for optimisation.
kern.transforms.index = [1 2];
kern.transforms.type = optimiDefaultConstraint('positive');
kern.isStationary = true;

% it requires a field with the additional information
