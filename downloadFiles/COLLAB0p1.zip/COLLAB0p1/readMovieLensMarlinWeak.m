function [Y, Ytest] = readMovieLensMarlinWeak(partNo)

% READMOVIELENSMARLINWEAK Read in Marlin's weak partitions for movielens 1M.
%
%	Description:
%
%	[Y, YTEST] = READMOVIELENSMARLINWEAK(PARTNO) reads the Movielens 1M
%	Marlin weak partitions.
%	 Returns:
%	  Y - the data.
%	  YTEST - the test data.
%	 Arguments:
%	  PARTNO - the part of the Movielens data to read in.
%	
%
%	See also
%	COLLABLOADDATA, READMOVIELENSMARLINSTRONG


%	Copyright (c) 2009 Raquel Urtasun
% 	readMovieLensMarlinWeak.m SVN version 348
% 	last update 2009-05-14T18:34:38.000000Z


baseDir = datasetsDirectory;
dirSep = filesep;

% load the ratings


fileName = [baseDir dirSep 'collab' dirSep 'project' dirSep '1mml-mmmf' dirSep 'data' dirSep 'marlin.mat'];

disp(['Reading ... ',fileName]);

load(fileName);

Y = weaktrain{partNo}';
Ytest = weaktest{partNo}';


        
