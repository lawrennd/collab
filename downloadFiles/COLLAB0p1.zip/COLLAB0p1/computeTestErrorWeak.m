function [L2_error,NMAE_error,NMAE_round_error] = computeTestErrorWeak(model,Y,Ytest)

% COMPUTETESTERRORWEAK Compute the weak test error.
%
%	Description:
%
%	[L2_ERROR, NMAE_ERROR, NMAE_ROUND_ERROR] =
%	COMPUTETESTERRORWEAK(MODEL, Y, YTEST) computes the test error for
%	the weak generalization.
%	 Returns:
%	  L2_ERROR - the l2 error.
%	  NMAE_ERROR - the NMAE error.
%	  NMAE_ROUND_ERROR - the NMAE error with rounding on the outputs.
%	 Arguments:
%	  MODEL - the model.
%	  Y - the training data.
%	  YTEST - the test data.
%	
%
%	See also
%	COMPUTETESTERRORSTRONG


%	Copyright (c) 2009 Raquel Urtasun
% 	computeTestErrorWeak.m SVN version 342
% 	last update 2009-05-07T10:23:14.000000Z
  
 
val_L2 = 0;
tot_L2 = 0;
val_NMAE = 0;
tot_NMAE = 0;
val_round_NMAE = 0;
tot_round_NMAE = 0;
accum = [];

for i = 1:size(Y, 2)       
  ind = find(Ytest(:, i));
  elim = find(ind>size(model.X, 1));
  tind = ind;
  tind(elim) = [];
  [mu, varsig] = collabPosteriorMeanVar(model, Y(:, i), model.X(tind, :));
  a = Ytest(tind, i) - mu; 
  a = [a; Ytest(elim, i)];
  val_L2 = val_L2 + a'*a;
  tot_L2 = tot_L2 + length(a);
  val_NMAE = val_NMAE + sum(abs(a));
  tot_NMAE = tot_NMAE + length(a);
  val_round_NMAE = val_round_NMAE + sum(abs(round(a)));
  tot_round_NMAE = tot_round_NMAE + length(a);
  accum = [accum; abs(a)];
end
L2_error = sqrt(val_L2/tot_L2);
NMAE_error = (val_NMAE/tot_NMAE)/1.6;
NMAE_round_error = (val_round_NMAE/tot_round_NMAE)/1.6;
