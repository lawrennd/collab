function options = collabOptimiseOptions

% COLLABOPTIMISEOPTIONS returns default options for collaborative filter optimisation.
%
%	Description:
%
%	OPTIONS = COLLABOPTIMISEOPTIONS returns default options for the
%	optimization of the collaborative filter.
%	 Returns:
%	  OPTIONS - the default options structure.
%	
%
%	See also
%	COLLABOPTIMISE, COLLABCREATE


%	Copyright (c) 2008 Neil D. Lawrence
% 	collabOptimiseOptions.m SVN version 334
% 	last update 2009-04-22T20:58:58.000000Z
  
  options.momentum = 0.5;
  options.learnRate = 0.0001;
  options.paramMomentum = 0.5;
  options.paramLearnRate = 0.0001;
  options.diagMomentum = 0.5;
  options.diagLearnRate = 0.0001;
  options.optimiseParam = true;
  options.showEvery = 100;
  options.saveEvery = 10000;
  options.showLikelihood = true;
  options.numIters = 50;
  options.saveName = 'save';
 end
