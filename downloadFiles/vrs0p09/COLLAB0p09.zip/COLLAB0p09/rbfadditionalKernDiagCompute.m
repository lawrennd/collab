function k = rbfadditionalKernDiagCompute(kern, x)

% RBFADDITIONALKERNDIAGCOMPUTE Compute diagonal of RBF side information kernel.
%
%	Description:
%
%	K = RBFADDITIONALKERNDIAGCOMPUTE(KERN, INDICES.) computes the
%	diagonal of the kernel matrix for the radial basis function kernel
%	given a design matrix of inputs.
%	 Returns:
%	  K - a vector containing the diagonal of the kernel matrix computed
%	   at the given points.
%	 Arguments:
%	  KERN - the kernel structure for which the matrix is computed.
%	  INDICES. - % ARG i - input data indices.
%	rbfaddtiionalKernCompute
%	
%	
%
%	See also
%	RBFADDITIONALKERNPARAMINIT, KERNDIAGCOMPUTE, KERNCREATE, 


%	Copyright (c)  Raquel Urtasun 2009
%	Copyright (c) 2004, 2005, 2006 Neil D. Lawrence
% 	rbfadditionalKernDiagCompute.m SVN version 334
% 	last update 2009-04-22T17:49:04.000000Z

k = repmat(kern.variance, size(x, 1), 1);
