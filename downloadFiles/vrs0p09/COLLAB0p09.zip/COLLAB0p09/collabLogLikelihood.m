function ll = collabLogLikelihood(model, y)

% COLLABLOGLIKELIHOOD Compute the log likelihood of a COLLAB.
%
%	Description:
%
%	LL = COLLABLOGLIKELIHOOD(MODEL) computes the log likelihood of a
%	data set given a COLLAB model.
%	 Returns:
%	  LL - the log likelihood of the data in the COLLAB model.
%	 Arguments:
%	  MODEL - the COLLAB model for which log likelihood is to be
%	   computed.
%	
%
%	See also
%	COLLABCREATE, COLLABLOGLIKEGRADIENTS, MODELLOGLIKELIHOOD


%	Copyright (c) 2009 Neil D. Lawrence
% 	collabLogLikelihood.m SVN version 334
% 	last update 2009-04-20T01:12:30.000000Z

  ll = 0;
  for i = 1:size(y, 2)
    ind = find(y(:, i));
    K = kernCompute(model.kern, model.X(ind, :));
    if model.heteroNoise
      n = length(ind);
      K = K + spdiags(model.diagvar(ind, :), 0, n, n);
    end
    [invK, U] = pdinv(K);
    logDetK = logdet(K, U);
    yind = y(ind, i);
    ll = ll - 0.5*logDetK - 0.5*yind'*invK*yind;
  end
end