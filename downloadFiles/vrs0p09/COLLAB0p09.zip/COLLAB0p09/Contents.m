% COLLAB toolbox
% Version 0.09		22-Apr-2009
% Copyright (c) 2009, Neil D. Lawrence
% 
, Neil D. Lawrence
% COLLABLOGLIKEGRADIENTS Gradient of the latent points.
% COLLABOPTIONSTENSOR Return default options for COLLAB model with a tensor
% RBFADDITIONALKERNDIAGGRADX Gradient of RBF with side information kernel's
% DEMMOVIELENS2 Try collaborative filtering on the large movielens data.
% DEMMOVIELENS4 Try collaborative filtering on the large movielens data.
% COLLABLOADDATA Load a collaborative filtering dataset.
% RBFADDITIONALKERNDIAGCOMPUTE Compute diagonal of RBF side information kernel.
% RBFADDITIONALKERNGRADIENT Gradient of RBF with side information kernel's parameters.
% DEMNETFLIX5 Try collaborative filtering on the netflix data.
% DEMMOVIELENSORDERED1 Try collaborative filtering on the large movielens data.
% DEMMOVIELENS3 Try collaborative filtering on the large movielens data.
% COLLABLOGLIKELIHOOD Compute the log likelihood of a COLLAB.
% COLLABOPTIONS Return default options for COLLAB model.
% DEMMOVIELENS1 Try collaborative filtering on the large movielens data.
% RBFADDITIONALKERNEXPANDPARAM Create kernel structure from RBF kernel's parameters.
% COLLABDISPLAY Displays the provided collaborative filter model.
% RBFADDITIONALKERNGRADX Gradient of RBF kernel with respect to input locations.
% COLLABOPTIMISEOPTIONS returns default options for collaborative filter optimisation.
% COLLABCREATE Create a COLLAB model with inducing varibles/pseudo-inputs.
% DEMNETFLIX1 Try collaborative filtering on the netflix data.
% DEMMOVIELENSSMALL1 Try collaborative filtering on the small movielens data.
% COLLABTOOLBOXES Load in the relevant toolboxes for collaborative filtering.
% DEMNETFLIX2 Try collaborative filtering on the netflix data.
% COLLABOPTIMISE Optimise the collaborative filter.
% RBFADDITIONALKERNPARAMINIT RBF kernel with side information.
% DEMNETFLIX3 Try collaborative filtering on the netflix data.
% RBFADDITIONALKERNCOMPUTE Compute the RBF kernel given the parameters and X.
% COLLABPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
