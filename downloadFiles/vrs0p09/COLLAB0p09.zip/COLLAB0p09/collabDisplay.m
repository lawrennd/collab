function collabDisplay(model, spaceNum)

% COLLABDISPLAY Displays the provided collaborative filter model.
%
%	Description:
%
%	COLLABDISPLAY(MODEL, SPACENUM) displays the collaborative model as
%	provided.
%	 Arguments:
%	  MODEL - the model to display.
%	  SPACENUM - number of spaces to indent display.
%	
%
%	See also
%	MODELDISPLAY


%	Copyright (c) 2008 Neil D. Lawrence
% 	collabDisplay.m SVN version 334
% 	last update 2009-04-22T20:58:39.000000Z

  if nargin > 1
    spacing = repmat(32, 1, spaceNum);
  else
    spaceNum = 0;
    spacing = [];
  end
  spacing = char(spacing);
  fprintf(spacing);
  fprintf('Collaborative filter GPLVM:\n')
  fprintf(spacing);
  fprintf('  Number of data points: %d\n', model.N);
  fprintf(spacing);
  fprintf('  Input dimension: %d\n', model.q);
  fprintf(spacing);
  fprintf('  Number of processes: %d\n', model.d);
  fprintf(spacing);
  fprintf('  Kernel:\n')

  kernDisplay(model.kern, spaceNum+2)
end