
% COLLABTOOLBOXES Load in the relevant toolboxes for collaborative filtering.
%
%	Description:
%	% 	collabToolboxes.m SVN version 337
% 	last update 2009-04-22T21:15:59.000000Z
importLatest('netlab');
importLatest('ndlutil');
importLatest('mltools');
importLatest('optimi');
importLatest('datasets');
importLatest('kern');
importLatest('ivm');
importLatest('gplvm');
importLatest('noise');