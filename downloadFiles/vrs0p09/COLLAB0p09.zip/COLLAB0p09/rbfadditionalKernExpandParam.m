function kern = rbfadditionalKernExpandParam(kern, params)

% RBFADDITIONALKERNEXPANDPARAM Create kernel structure from RBF kernel's parameters.
%
%	Description:
%
%	KERN = RBFADDITIONALKERNEXPANDPARAM(KERN, PARAM) returns a radial
%	basis function kernel structure, for use with side information,
%	filled with the parameters in the given vector. This is used as a
%	helper function to enable parameters to be optimised in, for
%	example, the NETLAB optimisation functions.
%	 Returns:
%	  KERN - kernel structure with the given parameters in the relevant
%	   locations.
%	 Arguments:
%	  KERN - the kernel structure in which the parameters are to be
%	   placed.
%	  PARAM - vector of parameters which are to be placed in the kernel
%	   structure.
%	
%	
%
%	See also
%	RBFKERNPARAMINIT, RBFKERNEXTRACTPARAM, KERNEXPANDPARAM


%	Copyright (c) 2004, 2005, 2006 Neil D. Lawrence
%	Copyright (c)  Raquel Urtasun
% 	rbfadditionalKernExpandParam.m SVN version 334
% 	last update 2009-04-22T17:50:57.000000Z

kern.inverseWidth = params(1);
kern.variance = params(2);
